﻿using Camed.SSC.Core.Commands;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Application.Requests.Inbox.Commands.Salvar
{
    public class ListById
    {
        public int Id { get; set; }
       
    }
}
