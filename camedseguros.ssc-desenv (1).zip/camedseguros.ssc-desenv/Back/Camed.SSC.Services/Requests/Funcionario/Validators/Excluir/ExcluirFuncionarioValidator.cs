﻿using Camed.SSC.Application.Requests.Funcionario.Commands.Excluir;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Application.Requests.Funcionario.Validators.Excluir
{
    public class ExcluirFuncionarioValidator : AbstractValidator<ExcluirFuncionarioCommand>
    {
    }
}
