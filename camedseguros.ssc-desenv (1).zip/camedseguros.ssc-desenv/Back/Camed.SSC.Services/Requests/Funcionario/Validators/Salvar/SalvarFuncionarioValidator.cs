﻿using Camed.SSC.Application.Requests.Funcionario.Commands.Salvar;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Application.Requests.Funcionario.Validators.Salvar
{
    public class SalvarFuncionarioValidator : AbstractValidator<SalvarFuncionarioCommand>
    {
    }
}
