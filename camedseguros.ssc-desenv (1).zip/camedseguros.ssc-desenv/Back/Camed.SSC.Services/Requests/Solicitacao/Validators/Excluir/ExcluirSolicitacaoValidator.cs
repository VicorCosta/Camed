﻿using Camed.SSC.Application.Requests.Solicitacao.Command.Excluir;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Application.Requests.Solicitacao.Validators.Excluir
{
    public class ExcluirSolicitacaoValidator : AbstractValidator<ExcluirSolicitacaoCommand>
    {
    }
}
