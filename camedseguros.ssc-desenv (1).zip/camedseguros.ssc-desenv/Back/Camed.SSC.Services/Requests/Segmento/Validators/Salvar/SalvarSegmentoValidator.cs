﻿using Camed.SSC.Application.Requests.Segmento.Commands.Salvar;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Application.Requests.Segmento.Validators.Salvar
{
    public class SalvarSegmentoValidator : AbstractValidator<SalvarSegmentoCommand>
    {
    }
}
