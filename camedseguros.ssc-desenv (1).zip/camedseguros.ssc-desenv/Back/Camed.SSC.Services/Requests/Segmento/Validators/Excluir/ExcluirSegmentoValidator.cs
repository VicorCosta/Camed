﻿using Camed.SSC.Application.Requests.Inbox.Commands.Excluir;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Application.Requests.Segmento.Validators.Excluir
{
    public class ExcluirSegmentoValidator : AbstractValidator<ExcluirInboxCommand>
    {
    }
}
