﻿using Camed.SSC.Core.Interfaces;

namespace Camed.SSC.Core.Handlers
{
    public class HandlerBase
    {
        protected IResult result = new Result();
    }
}
