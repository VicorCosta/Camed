﻿using Camed.SSC.Core.Interfaces;

namespace Camed.SSC.Core.Entities
{
    public abstract class EntityBase : IEntity
    {
        public int Id { get; set; }
    }
}
