﻿namespace Camed.SSC.Core.Interfaces
{
    public interface IEntity
    {
        int Id { get; }
    }
}
