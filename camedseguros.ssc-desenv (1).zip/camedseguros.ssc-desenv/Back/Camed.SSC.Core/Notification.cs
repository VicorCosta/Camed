﻿namespace Camed.SSC.Core
{
    public class Notification
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
