﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Core.Enums
{
    public enum SortDirection
    {
        Ascending = 0,
        Descending = 1
    }
}
