﻿using System;

namespace Camed.SCC.Infrastructure.CrossCutting.Dto
{
    public class ResultProcedure
    {

    }
}



