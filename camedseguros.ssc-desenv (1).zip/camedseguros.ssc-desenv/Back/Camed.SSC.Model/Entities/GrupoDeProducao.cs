﻿using Camed.SSC.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Domain.Entities
{
    public class GrupoDeProducao : EntityBase
    {
        public string Nome { get; set; }
    }
}
