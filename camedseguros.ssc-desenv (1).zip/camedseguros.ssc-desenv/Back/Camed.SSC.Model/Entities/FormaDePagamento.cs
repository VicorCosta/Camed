﻿using Camed.SSC.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Domain.Entities
{
    public class FormaDePagamento : EntityBase
    {
        public string Ds_Forma { get; set; }
    }
}
