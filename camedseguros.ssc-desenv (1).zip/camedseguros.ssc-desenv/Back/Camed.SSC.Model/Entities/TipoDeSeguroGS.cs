﻿using Camed.SSC.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Camed.SSC.Domain.Entities
{
    public class TipoDeSeguroGS : EntityBase
    {
        public string nm_Abrev { get; set; }
    }
}
