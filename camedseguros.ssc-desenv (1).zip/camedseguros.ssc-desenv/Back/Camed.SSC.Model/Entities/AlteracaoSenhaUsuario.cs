﻿using Camed.SSC.Core.Entities;
using System.Collections.Generic;


namespace Camed.SSC.Domain.Entities {
    public class AlteracaoSenhaUsuario : EntityBase {
        
    }
}