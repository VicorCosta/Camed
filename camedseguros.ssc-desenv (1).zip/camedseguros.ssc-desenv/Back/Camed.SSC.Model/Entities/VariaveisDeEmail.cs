﻿using Camed.SSC.Core.Entities;
using System.Collections.Generic;


namespace Camed.SSC.Domain.Entities
{
    public class VariaveisDeEmail : EntityBase
    {
        public string Nome { get; set; }
        public int? Parametro_Id { get; set; }
    }
}
